<?php
require_once "./router.php";
exit();
?>